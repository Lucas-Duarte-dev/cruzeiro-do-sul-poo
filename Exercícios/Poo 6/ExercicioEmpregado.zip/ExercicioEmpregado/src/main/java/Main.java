/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        
        float[] valorp = new float[200];
        
        // Estrutura de repetição para 
        
        int n = Integer.parseInt(JOptionPane.showInputDialog(null, "Quantidade de projetos: "));
                
        for(int i = 0; i < n; i++) {
            valorp[i] = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor do projeto" + (i + 1)));
        }
        
       float valorH, qtdHora;
       String nom, matri;
       
       valorH = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor por hora: "));
       qtdHora = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite a quantidade de horas trabalhadas: "));
       
       
       
       nom = JOptionPane.showInputDialog(null, "Digite seu nome: ");
       matri = JOptionPane.showInputDialog(null, "Digite sua matricula: ");
       
      
       
       Analista a = new Analista();
        a.setNome(nom);
        a.setMatricula(matri);
        a.setValorPorProjeto(valorp);
        
       Programador p = new Programador();
        p.setMatricula(matri);
        p.setNome(nom);
        p.setQtdeHoras(qtdHora);
        p.setValorHora(valorH);
        
        
       //Mostra de Dados
       
       JOptionPane.showMessageDialog(null, "_____ANALISTA_____" +
               "\nNome: " + a.nome +
               "\nMatricula: " + a.matricula +
               "\nValor por projeto: " + a.calcularSalario());
       
       
       JOptionPane.showMessageDialog(null, "_____PROGRAMADOR_____" +
               "\nNome: " + p.nome +
               "\nMatricula: " + p.matricula +
               "\nValor Final: " + p.calcularSalario());
    
    }
    
}
