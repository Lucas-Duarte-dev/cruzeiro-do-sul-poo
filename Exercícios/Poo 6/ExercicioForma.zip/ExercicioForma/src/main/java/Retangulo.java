/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */



public class Retangulo extends Triangulo{

    public Retangulo() {
    }

    public Retangulo(float base, float altura) {
        super(base, altura);
    }
    public float area() {
        return getBase() * getAltura();
    }
    public float perimetro() {
        return (getBase() * getAltura())/2;
    }
    

    public void mostra() {
    System.out.println(
            "Retangulo" +
            "\nArea: " + area() +
            "\nPerimetro: " + perimetro());
    }
    

}

