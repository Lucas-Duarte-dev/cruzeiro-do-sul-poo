

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
public class Circuferencia extends Forma{
    
    private float raio;
    
    public Circuferencia(float raio) {
        
        this.raio = raio;
    }

    public float getRaio() {
        return raio;
    }

    public void setRaio(float raio) {
        this.raio = raio;
    }
  
    @Override
    public float area() {
        return (float)Math.PI * (raio * raio);
    }
    
    @Override
    public float perimetro() {
        return (float)(2 *Math.PI) * raio;
    }
    
   @Override
   public void mostra() {
       System.out.println("Raio: " + raio +
               "\nArea: " + area() +
               "\nPerimetro: " + perimetro());
   }

   
    
    
    
    
}
