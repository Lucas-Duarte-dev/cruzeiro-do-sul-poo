/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        float raiz, base, altura;
        
        raiz = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor da raiz: "));
        base = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor da base: "));
        altura = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor da altura: "));
        
        Circuferencia c = new Circuferencia(raiz);
        c.area();
        c.perimetro();
        c.mostra();
        Retangulo r = new Retangulo(base, altura);
        r.area();
        r.perimetro();
        r.mostra();
    }
}
