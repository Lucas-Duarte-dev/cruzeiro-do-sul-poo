/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        String nomeA, turmaA;
        int qAlunos;
        float mensal;
        nomeA = JOptionPane.showInputDialog(null, "Digite o seu nome: ");
        turmaA = JOptionPane.showInputDialog(null, "Digite a sua turma: ");
        qAlunos = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a quantidade de alunos: "));
        mensal = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor da mensalidade: "));
        
        Curso c = new Curso(nomeA, qAlunos, turmaA, mensal);
        
        c.imprimeDados();
        c.calculaTotalMensalidade();
       
    }
}
