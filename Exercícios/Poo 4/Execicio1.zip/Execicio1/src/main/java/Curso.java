/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
import javax.swing.JOptionPane;

public class Curso {
    String nome;
    int quantidadeAluno;
    String turma;
    float mensalidade;
    
    Curso(){}
    Curso(String nome, int quantidadeAluno, String turma, float mensalidade) {
        this.nome = nome;
        this.quantidadeAluno = quantidadeAluno;
        this.turma = turma;
        this.mensalidade = mensalidade;
    }

    void imprimeDados(){
        JOptionPane.showMessageDialog(null, "Nome: " + nome 
                + "\nQuantidade de Aluno: " + quantidadeAluno +
                "\nTurma: " + turma 
                + "\nMensalidade: " + mensalidade );
    }
    
    float calculaTotalMensalidade() {
        float mensalidadeTotal = quantidadeAluno * mensalidade;
        JOptionPane.showMessageDialog(null, "Mensalidade Total: " + mensalidadeTotal);
        return mensalidadeTotal;
        
    }            
}
