/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args){
        String nomeA;
        int atual;
        nomeA = JOptionPane.showInputDialog(null, "Digite o seu nome: ");
        
        Paciente p = new Paciente(nomeA);
        p.rg = JOptionPane.showInputDialog(null, "Digite o seu RG: ");
        p.endereco = JOptionPane.showInputDialog(null, "Digite o seu endereço: ");
        p.telefone = JOptionPane.showInputDialog(null, "Digite o seu número de telefone: ");
        p.anoNascimento = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o seu ano de nascimento: "));
        p.proficao = JOptionPane.showInputDialog(null, "Qual a sua profição: ");
        
        atual = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o ano atual"));
        p.calculaIdade(atual);
        p.imprimeDados();
    }
}
