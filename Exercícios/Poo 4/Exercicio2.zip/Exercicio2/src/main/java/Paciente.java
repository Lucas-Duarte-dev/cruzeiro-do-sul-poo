/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
import javax.swing.JOptionPane;

public class Paciente {
    String nome;
    String rg;
    String endereco;
    String telefone;
    int anoNascimento;
    String proficao;
    
    Paciente(){}
    Paciente(String nome){
        this.nome = nome;
    }
    void imprimeDados(){
        JOptionPane.showMessageDialog(null, "Nome: " + nome 
        + "\nRG: " + rg 
        + "\nEndereço: " + endereco 
        + "\nTelefone: " + telefone 
        + "\nIdade: " + anoNascimento 
        + "\nProfição: " + proficao);
    }
    int calculaIdade(int anoatual){
       anoNascimento = anoatual - anoNascimento;
        return anoNascimento;
    }
    
    
}
