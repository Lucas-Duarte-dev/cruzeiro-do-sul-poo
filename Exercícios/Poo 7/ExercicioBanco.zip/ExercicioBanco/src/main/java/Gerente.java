/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
public class Gerente extends Funcionario {
  private int senha;
  private int funcionariosGerenciados;

    public Gerente() {
    }

    public Gerente(int senha, int funcionariosGerenciados) {
        this.senha = senha;
        this.funcionariosGerenciados = funcionariosGerenciados;
    }

    public Gerente(int senha, int funcionariosGerenciados, String name, String cpf, double salario) {
        super(name, cpf, salario);
        this.senha = senha;
        this.funcionariosGerenciados = funcionariosGerenciados;
    }
    

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    public int getFuncionariosGerenciados() {
        return funcionariosGerenciados;
    }

    public void setFuncionariosGerenciados(int funcionariosGerenciados) {
        this.funcionariosGerenciados = funcionariosGerenciados;
    }

    @Override
    public Boolean atenticao() {        
      if(this.senha == 123){
          System.out.println("Acesso permite!");
          return true;
      } else {
          System.exit(0);
          System.out.println("Acesso negado!");
          
          return false;  
      }
    }

    
    
    @Override
    public Double bonificacao() {
        return getSalario() + (getSalario() * 0.15); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String mostraDados() {
        return "------- Gerente ------" +
               "\nNome: " + getName() + "\nCPF: " + getCpf() + "\nSalário: " + getSalario() 
               + "\nFuncionários Gerenciados" + funcionariosGerenciados; 
    }
  
    
  
    
    
}
