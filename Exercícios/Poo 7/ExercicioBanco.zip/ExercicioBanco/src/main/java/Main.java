/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        String nomeValue, cpfValue;
        double salarioValue;
        int senhaValue, funcionarioG;
        
        Funcionario f = null;
        while(true) {
            int value = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o valor correspondente" +
                    "\n1 - Gerente" +
                    "\n2 - Caixa" + 
                    "\n3 - Funcionário" + 
                    "\n4 - Sair"
                    ));
            switch(value) {
                case 1: 
                    senhaValue = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite seu senha: "));
                    funcionarioG = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a quantidade de funcionários que você gerencia: "));
                    f= new Gerente(senhaValue, funcionarioG);
                    f.atenticao();
                    
                    nomeValue = JOptionPane.showInputDialog(null, "Digite seu nome: ");
                    cpfValue = JOptionPane.showInputDialog(null, "Digite seu cpf: ");
                    salarioValue = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite seu salário: "));
                    f = new Gerente(senhaValue, funcionarioG, nomeValue, cpfValue, salarioValue);
                    
                    break;
                case 2: 
                    nomeValue = JOptionPane.showInputDialog(null, "Digite seu nome: ");
                    cpfValue = JOptionPane.showInputDialog(null, "Digite seu cpf: ");
                    salarioValue = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite seu salário: "));
                    f = new Caixa(nomeValue, cpfValue, salarioValue);
                    break;
                case 3: 
                    nomeValue = JOptionPane.showInputDialog(null, "Digite seu nome: ");
                    cpfValue = JOptionPane.showInputDialog(null, "Digite seu cpf: ");
                    salarioValue = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite seu salário: "));
                    f = new Funcionario(nomeValue, cpfValue, salarioValue);
                    break;
                case 4: 
                    System.out.println("Bye...bye");
                    System.exit(0);
                    break;
                default: {
                    System.out.println("Erro: Opção inválida");
                    System.exit(0);
                }
                    
            }
            JOptionPane.showMessageDialog(null, f.mostraDados() + "\nBonificação: " + f.bonificacao());

        }
        
    }
}
