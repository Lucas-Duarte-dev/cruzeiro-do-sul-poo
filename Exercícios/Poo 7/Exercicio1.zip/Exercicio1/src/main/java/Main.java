/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        
        String rgmValue, campusValue, setorValue, nomeValue;
        int matriculaValue;
        

        Pessoa p = null ;
        while (true) {
            int tipo = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite uma das opções abaixo: " +
                    "\n1 - Aluno" +
                    "\n2 - Professor" + 
                    "\n3 - Funcionário" + 
                    "\n4 - Sair"));
            switch(tipo) {
                case 1:
                    rgmValue = JOptionPane.showInputDialog(null, "Digite seu RGM: ");
                    nomeValue = JOptionPane.showInputDialog(null, "Digite seu nome: ");
                    p = new Aluno(rgmValue, nomeValue);
                    break;
                case 2:
                    nomeValue = JOptionPane.showInputDialog(null, "Digite seu nome: ");
                    campusValue = JOptionPane.showInputDialog(null, "Digite seu campus: ");
                    matriculaValue = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a sua matricula: "));
                    p = new Professor(matriculaValue, campusValue, nomeValue);
                    break;
                case 3: 
                    nomeValue = JOptionPane.showInputDialog(null, "Digite seu nome: ");
                    matriculaValue = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a sua matricula: "));
                    setorValue = JOptionPane.showInputDialog(null, "Digite seu setor: ");
                    p = new Funcionario(matriculaValue, setorValue, nomeValue);
                    break;
                case 4: 
                    System.out.println("Bye...bye");
                    System.exit(0);
                    break;
                default: {
                    System.out.println("Erro: Opção inválida");
                    System.exit(0);
                }

            }
               System.out.println(p.mostrarClasse());

        }
    }
}