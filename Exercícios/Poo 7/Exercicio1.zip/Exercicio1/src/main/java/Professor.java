/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */

public class Professor extends Pessoa{
    
    private int matricula;
    private String Campus;

    public Professor() {
    }

    public Professor(int matricula, String Campus) {
        this.matricula = matricula;
        this.Campus = Campus;
    }

    public Professor(int matricula, String Campus, String nome) {
        super(nome);
        this.matricula = matricula;
        this.Campus = Campus;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getCampus() {
        return Campus;
    }

    public void setCampus(String Campus) {
        this.Campus = Campus;
    }

    @Override
    public String mostrarClasse() {
        return "Nome:" + getNome() + "\nMatricula: " + matricula + "\nCampus: " + Campus;
    }


    
    
    
    
    
}
