/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
public class Aluno extends Pessoa{
    private String rgm;

    public Aluno() {
    }

    public Aluno(String rgm) {
        this.rgm = rgm;
    }

    public Aluno(String rgm, String nome) {
        super(nome);
        this.rgm = rgm;
    }

    public String getRgm() {
        return rgm;
    }

    public void setRgm(String rgm) {
        this.rgm = rgm;
    }

    

    @Override
    public String mostrarClasse() {
        return "Nome:" + getNome() + "\nRGM: " + rgm;
    }
    
    
  
}
