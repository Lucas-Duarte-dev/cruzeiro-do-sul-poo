/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        Aluno a = null;
        ArrayAluno aa = new ArrayAluno();
        
        while(true) {
            int opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite uma opção: " + 
                    "\n1 - Cadastrar Aluno" + 
                    "\n2 - Selecionar Aluno" + 
                    "\n3 - Mostrar todos" + 
                    "\n4 - Dados do Projeto" +
                    "\n5 - Sair"));
            switch (opcao) {
                case 1: 
                    
                    String rgm = JOptionPane.showInputDialog(null, "Digite seu RGM: ");
                    if(aa.seleciona(rgm) == null) {
                        String nome = JOptionPane.showInputDialog(null, "Digite seu nome: ");
                        float notaParcial = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite sua nota da prova Parcial: "));
                        float notaRegimental = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite sua nota da prova Regimental: "));
                        a = new Aluno(rgm, nome, notaParcial, notaRegimental);
                     if (aa.inserir(a)) {
                        JOptionPane.showMessageDialog(null, "Aluno cadastrado com sucesso! ");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error: Falha ao cadastrar aluno! ");
                    }
                    } else {
                        JOptionPane.showMessageDialog(null, "Aluno já cadastrado");
                    }
                    break;
                case 2: 
                    String query = JOptionPane.showInputDialog(null, "Digite o RGM do aluno que deseja pesquisar: ");
                    if(aa.seleciona(query) == null) {
                        JOptionPane.showMessageDialog(null, "Registro não econtrado! ");
                    } else {
                        
                        JOptionPane.showMessageDialog(null, a.calcularMedia());
                        aa.seleciona(query).print();
                        
                    }
                    break;
                case 3:
                    aa.selecionaTodos().forEach(alunos -> {
                        alunos.print();
                    });
                    break;
                    
                case 4: 
                   JOptionPane.showMessageDialog(null, 
                           "Nome: Lucas Duarte" + " RGM: 2261833-3" + 
                           "\nNome: Vitor Oliveira" + " RGM: 2306368-8" + 
                           "\nNome: Francisco Gustavo" + " RGM: 2306090-5" + 
                           "\nVersão:  brasileira herbert richers");
                    
                case 5:
                    
                    System.exit(0);
                    break;
                    
                default:
                    JOptionPane.showMessageDialog(null, "Opção invalida");
            }
        }
    }
}
