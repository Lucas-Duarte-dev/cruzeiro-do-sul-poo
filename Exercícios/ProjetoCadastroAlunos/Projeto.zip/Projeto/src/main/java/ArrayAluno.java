/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
import java.util.ArrayList;
import java.util.List;


public class ArrayAluno extends Aluno implements Interface{

    private List<Aluno> alunos = new ArrayList<>();
    
    @Override
    public boolean inserir(Aluno p) {
        
      alunos.add(p);  
       
      return true; 
    }

    @Override
    public Aluno seleciona(String rgm) {
       Aluno aluno = null;
       for(Aluno a : alunos) {
           if(rgm.equals(a.getRgm())) {
              
               
               return a;
           }
       }
       return aluno;
    }

    @Override
    public List<Aluno> selecionaTodos() {
        return alunos;
    }

}
