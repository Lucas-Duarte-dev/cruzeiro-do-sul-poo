
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
public class Aluno {
    private String rgm;
    private String nome;
    private float notaParcial;
    private float notaReg;

    public Aluno() {
    }

    public Aluno(String rgm, String nome, float notaParcial, float notaReg) {
        this.rgm = rgm;
        this.nome = nome;
        this.notaParcial = notaParcial;
        this.notaReg = notaReg;
    }

    public String getRgm() {
        return rgm;
    }

    public void setRgm(String rgm) {
        this.rgm = rgm;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getNotaParcial() {
        return notaParcial;
    }

    public void setNotaParcial(float notaParcial) {
        this.notaParcial = notaParcial;
    }

    public float getNotaReg() {
        return notaReg;
    }

    public void setNotaReg(float notaReg) {
        this.notaReg = notaReg;
    }
    
    public float mediaAluno() {
        
        float media = getNotaParcial() + getNotaReg();
        
        return media;
    }
    
    public String calcularMedia() {
        if(mediaAluno()>= 6.0 && mediaAluno()<= 10.0) {
           return "Aprovado";
        } else if(mediaAluno() >= 3.0 && mediaAluno() <= 5) {
            return "Avaliação Final";
        } else {
            return "Reprovado";
        }
        
    }
    
    public void print() {
        JOptionPane.showMessageDialog(null, "RGM: " + rgm + 
                "\nNome: " + nome + 
                "\nNota Parcial: " + notaParcial +
                "\nNota Regimental: " + notaReg);
    }
    
}
