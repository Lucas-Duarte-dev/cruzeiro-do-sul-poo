


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */

import java.util.List;

public interface Interface{

   boolean inserir(Aluno p);
  
   Aluno seleciona(String rgm);
    
   List<Aluno> selecionaTodos();
  
  
}
