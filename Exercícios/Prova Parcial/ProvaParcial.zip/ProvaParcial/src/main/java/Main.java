
import java.util.Random;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
public class Main {
    public static void main(String[] args) {
           
        Random gerador = new Random();
                
        String nome, cpf;
        int numConta = gerador.nextInt(20);
         float saldoConta, valorConta;
         
         nome = JOptionPane.showInputDialog(null, "Digite seu nome: ");
         cpf = JOptionPane.showInputDialog(null, "Digite seu cpf:" );
         saldoConta = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite seu saldo inicial: "));
         
         Conta c = new Conta(numConta, saldoConta, nome, cpf);    
         
         
        while(true) {
            int opc = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o valor de acesso: " 
                + "\n1 - Depositar" 
                + "\n2 - Sacar" 
                + "\n3 - Imprimir Saldo"
                + "\n4 - Dados do projeto"
                + "\n5 - Sair"));
            switch(opc) {
                case 1: 
                    
                    valorConta = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor que deseja depositar: "));

                    c.depositar(valorConta);
                    c.mostrarSaldo();
                    break;
                case 2:    
                    valorConta = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor que deseja sacar: "));
                    
                    c.sacar(valorConta);
                    c.mostrarSaldo();
                    break;
                case 3:
                    c.mostrarDados();
                    break;
                case 4: 
                    JOptionPane.showMessageDialog(null, "RGM: 22618333" + "\nNome: Lucas Duarte Brandão Goes" + "\nVersion: 0.1");
                    break;
                case 5: 
                    System.exit(0);
                    break;
                    
                default: 
                    JOptionPane.showMessageDialog(null, "Opção inválida!");
                    System.exit(0);
            }
        }
        
    }
}
