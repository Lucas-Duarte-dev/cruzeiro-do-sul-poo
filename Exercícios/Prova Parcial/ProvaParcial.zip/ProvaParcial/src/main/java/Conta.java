

import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
public class Conta extends Pessoa implements Interface{

    private int numero; 
    private float saldo;

    public Conta() {
    }

    public Conta(int numero, float saldo) {
        this.numero = numero;
        this.saldo = saldo;
    }

    public Conta(int numero, float saldo, String nome, String cpf) {
        super(nome, cpf);
        this.numero = numero;
        this.saldo = saldo;
    }

    public Conta(int numero) {
        this.numero = numero;
    }

    public Conta(int numero, String nome, String cpf) {
        super(nome, cpf);
        this.numero = numero;
    }
    

    
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    @Override
    public void depositar(float valor) {
       saldo = saldo + valor;
    }

    @Override
    public void sacar(float valor) {
        if(saldo < valor) {
            JOptionPane.showMessageDialog(null, "Saldo insuficiente");
        } else {
            saldo = saldo - valor;
        }
        
    }
    
    public void mostrarSaldo() {
        JOptionPane.showMessageDialog(null, "Seu saldo é: R$" + saldo);
    }
    public void mostrarDados() {
        JOptionPane.showMessageDialog(null, "Nome: " + getNome() + "\nCPF: " + getCpf() + "\nNumero da Conta: " + numero +  "\nSaldo: " + saldo);
    }
    
    
}
