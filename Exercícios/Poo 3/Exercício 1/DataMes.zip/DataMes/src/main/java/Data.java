/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PC
 */
import javax.swing.JOptionPane;

public class Data {
    int dia;
    int mes;
    int ano;
    
    Data(){}
    
    Data(int dia, int mes, int ano) {
    this.dia = dia;
    this.mes = mes;
    this.ano = ano;
    }
    
    void cadastrar() {
        dia = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o dia de hoje: "));
        mes = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o dia de mês: "));
        ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o dia de ano: "));
    }
    
    void imprimeData() {
        JOptionPane.showMessageDialog(null, "Dia: " + dia + "\nMês: " + mes + "\nAno: " + ano);
    }
    
}
