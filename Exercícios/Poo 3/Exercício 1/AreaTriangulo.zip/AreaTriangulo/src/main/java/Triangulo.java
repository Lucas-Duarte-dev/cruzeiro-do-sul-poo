/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PC
 */
import javax.swing.JOptionPane;

public class Triangulo {
    float base;
    float altura;
    
    Triangulo(){}
    
    Triangulo(float base, float altura) {
    this.base = base;
    this.altura = altura;
    }
    float calculaArea(){
        
        float area; 
        area = base * altura/2;
        JOptionPane.showMessageDialog(null, "Area: " + area);
        return area;
    }
    
    void imprimeDados() {
        JOptionPane.showMessageDialog(null, "Base: " + base + "\nAltura: " + altura);
    }
   
    
}
