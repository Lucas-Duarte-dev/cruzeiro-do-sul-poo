/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
import javax.swing.JOptionPane;

public class ContaCorrente {
    String nome;
    float saldo;
    float limite;
    char tipo;
    
    ContaCorrente(){}
    ContaCorrente(String nome, float saldo, float limite, char tipo){
        this.nome = nome;
        this.saldo = saldo;
        this.limite = limite;
        this.tipo = tipo;
    }
    ContaCorrente(String nome, float saldo, char tipo){
    this.nome = nome;
    this.saldo = saldo;
    this.tipo = tipo;
    }
    
    
    void cadastrarDados(){  
        
    }
    void imprimirDados() {
        JOptionPane.showMessageDialog(null, "Dados da Conta Corrente: " + "\nNome: " + nome + "\nSaldo: " + saldo + "\nLimite: " + limite + "\nTipo: " + tipo);
    }
    void depositar(float valor) {
        
        saldo = valor + saldo;
    }
    void sacar(float valor) {
       
        saldo = valor - saldo;
       }
    
}
