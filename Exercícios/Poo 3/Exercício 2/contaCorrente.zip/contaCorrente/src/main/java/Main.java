/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */
import javax.swing.JOptionPane;
public class Main {
    public static void main(String[] args){
        ContaCorrente cc;
        
        float depositad, sacard, saldod, limited;
        String nomec;
       char tipot;
        
        nomec = JOptionPane.showInputDialog(null, "Digite seu nome: ");
        saldod = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o seu saldo: "));
        limited = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o seu limite: "));
        tipot = JOptionPane.showInputDialog(null, "Digite o tipo: ").charAt(0);
        
        cc = new ContaCorrente(nomec, saldod, limited, tipot);
        
        cc.imprimirDados();
        
        depositad = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor que quer depositar: "));
        cc.depositar(depositad);
        cc.imprimirDados();
        
        sacard = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o valor que quer sacar: "));
        cc.sacar(sacard);
        cc.imprimirDados();
        
        
        
      
    }
}
