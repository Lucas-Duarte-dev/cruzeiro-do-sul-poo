/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */

import javax.swing.JOptionPane;
public class Main {
    public static void main(String[] args) {
        String texto;
        int largura, altura;
        
        texto = JOptionPane.showInputDialog(null, "Digite um texto: ");
        largura = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a largura da caixa: "));
        altura = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a altura da caixa: "));
        
        
        Janela j = new Janela();
        j.JanelaJ(texto, largura, altura);
        
    }
}
