/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */

import java.util.Arrays;
import javax.swing.JOptionPane;


public class Main {
    public static void main(String[] args) {
        float soma = 0;
        int notas = 5;
        int media[] = new int[5];
        
        for(int i = 0; i < notas; i++) {
           media[i] = Integer.parseInt(JOptionPane.showInputDialog(null,
                   "Digita suas notas: "));
           
           System.out.println(Arrays.toString(media));
           
           soma += media[i];  
           
        }
        
        Arrays.sort(media);
        JOptionPane.showMessageDialog(null,"Media ordenada: " + Arrays.toString(media) );
        JOptionPane.showMessageDialog(null, "Média: " + soma / 5); 
    }
}
