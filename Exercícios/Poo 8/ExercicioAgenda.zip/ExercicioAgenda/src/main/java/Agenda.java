
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */



import java.util.Arrays;
import javax.swing.JOptionPane;

public class Agenda {
    
    private String[][] dados = new String[5][2];

    public Agenda() {
    }

    public Agenda(String[][] dados) {
        this.dados = dados;
    }

    public String[][] getDados() {
        return dados;
    }

    public void setDados(String[][] dados) {
        this.dados = dados;
    }
    
    

    public void entDados() {

        for (int i = 0; i < 5; i++) {
            dados[i][0] = JOptionPane.showInputDialog(null, "Digite seu nome: ");
            dados[i][1] = JOptionPane.showInputDialog(null, "Digite seu Telefone: ");
            Arrays.asList(dados);
            
        }
        
        System.out.println(Arrays.toString(dados));
    }
    
    public void imprimirDados() {
        for(int i = 0; i < dados.length; i++) {
        System.out.println("Pessoa: " + dados[i][0] + " Número: " + dados[i][1] );
        }
    }
    
    public String busca(String nome) { 
        for(int i = 0; i < dados.length; i++) {
        if(dados[i][0].equals(nome)) {
            return "Nome: " + dados[i][0] + " Número: " + dados[i][1];
        }

       }  
        return "";
    }
    
}