/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lkgg-
 */

import javax.swing.JOptionPane;




public class Main {
    public static void main(String[] args) {
        
        String nome;
        
        
         Agenda a = new Agenda();
        
        while(true) {
            int value = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o valor correspondente" +
                    "\n1 - Entrar com Dado" +
                    "\n2 - Ver lista" + 
                    "\n3 - Buscar Pessoa" + 
                    "\n4 - Sair"
                    ));
            switch(value) {
                case 1: 
                    a.entDados();
                    break;
                case 2: 
                    a.imprimirDados();
                    break;
                case 3: 
                    nome = JOptionPane.showInputDialog(null, "Digite a pessoa que quer buscar: ");
                    System.out.println(a.busca(nome));
                    break;
                case 4: 
                    System.out.println("Bye...bye");
                    System.exit(0);
                    break;
                default: {
                    System.out.println("Erro: Opção inválida");
                    System.exit(0);
                }
                    
            }
        
      }
   }
}
